#Código main que ejecuta el método principal que corre toda la partida, esencialmente es el ejecutable

from src.partida import Juego

#Este condicional permite que el código dentro de él solo se ejecute si el archivo se ejecuta directamente.
if __name__ == "__main__":
    juego = Juego()
    juego.ejecutar()
