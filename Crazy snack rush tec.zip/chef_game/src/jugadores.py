import time


class Cocinero:
    def __init__(self, x: int, y: int, color: str, nombre: str = "Cocinero"):
        self.x = x
        self.y = y
        self.color = color
        self.nombre = nombre
        self.sostiene = None
        self.direccion = "down"
        self.activo = False
        self.ultimo_movimiento = 0.0
        self.ultima_accion = 0.0


    def intentar_mover(self, dx: int, dy: int, cocina, now: float, retardo_movimiento: float) -> bool:
        if now - self.ultimo_movimiento < retardo_movimiento:
            return False
        new_x, new_y = self.x + dx, self.y + dy
        if cocina.es_transitable(new_x, new_y):
            self.x, self.y = new_x, new_y
            self.ultimo_movimiento = now
            if dx > 0:
                self.direccion = "right"
            elif dx < 0:
                self.direccion = "left"
            elif dy > 0:
                self.direccion = "down"
            elif dy < 0:
                self.direccion = "up"
            return True
        return False


    def puede_actuar(self, now: float, enfriamiento: float):
        return now - self.ultima_accion >= enfriamiento

    def marcar_accion(self, now: float):
        self.ultima_accion = now

    def es_adyacente(self, x: int, y: int):
        return abs(self.x - x) + abs(self.y - y) == 1

    def recoger(self, ingrediente):
        if self.sostiene is None:
            self.sostiene = ingrediente

    def soltar(self):
        ing = self.sostiene
        self.sostiene = None
        return ing

    def tiene_ingrediente(self):
        return self.sostiene is not None

    def __repr__(self):
        held = self.sostiene.nombre if self.sostiene else "nada"
        return f"{self.nombre}@({self.x},{self.y}) sosteniendo={held}"
