#Bloque de importaciones
import random
import time

from .jugadores import Cocinero
from .constantes import COLS_GRID, FILAS_GRID
from .recetas import Orden
from .estaciones import (
    Estacion, TipoEstacion,
    EstacionDespensa, EstacionEntrega, EstacionTrabajo,
    crear_estacion,
)

#Clase de la cocina que actua como escenario donde se desenvuelve la partida.
class Cocina:

#Constructor de la cocina
    def __init__(self, tema: dict):
        self.nombre_tema = tema["nombre"]
        self.tema = tema  
        self.muros = set()
        self.estaciones = {}  
        self.jugadores = []
        self.entrega = None
        self.despensas = []
        self.estaciones_trabajo = []
        self.ordenes_activas = []
        self.puntuacion = 0
        self.ultima_generacion_orden = time.time()
        self.ultima_actualizacion = time.time()
        self._parsear_mapa(tema)


# Método que crea el mapa de la cocina a partir del tema proporcionado.
    def _parsear_mapa(self, tema: dict) :
        mapa = tema["mapa"]
        ingredientes_despensa = tema["ingredientes"]

        for y, fila in enumerate(mapa):
            for x, c in enumerate(fila):
                if c == "#":
                    self.muros.add((x, y))
                elif c == ".":
                    pass  
                elif c == "1":
                    self.jugadores.append(Cocinero(x, y, "#E53935", "Cocinero 1"))
                elif c == "2":
                    self.jugadores.append(Cocinero(x, y, "#1E88E5", "Cocinero 2"))
                else:
                    estacion = crear_estacion(c, x, y, ingredientes_despensa)
                    if estacion is not None:
                        self.estaciones[(x, y)] = estacion
                        if estacion.tipo == TipoEstacion.ENTREGA:
                            self.entrega = estacion
                        elif estacion.tipo == TipoEstacion.DESPENSA:
                            self.despensas.append(estacion)
                        elif isinstance(estacion, EstacionTrabajo):
                            self.estaciones_trabajo.append(estacion)

        if self.jugadores:
            self.jugadores[0].activo = True

    
#Método que define por donde puede caminar el jugador 
    def es_transitable(self, x: int, y: int):
        
        # Límites del escenario
        if x < 0 or y < 0 or x >= COLS_GRID or y >= FILAS_GRID:
            return False
        if (x, y) in self.muros:
            return False
        if (x, y) in self.estaciones:
            return False  # las celdas con estación no son pisables
        return True
#Método que define la estación en la que se encuentra el jugador
    def obtener_estacion_en(self, x: int, y: int):
        return self.estaciones.get((x, y))
#Método que define el jugador activo
    def obtener_jugador_activo(self):
        for jugador in self.jugadores:
            if jugador.activo:
                return jugador
        return None
#Método que permite cambiar de jugador activo
    def cambiar_jugador(self):
        if not self.jugadores:
            return
        activo = self.obtener_jugador_activo()
        indice = self.jugadores.index(activo) if activo else 0
        for jugador in self.jugadores:
            jugador.activo = False
        self.jugadores[(indice + 1) % len(self.jugadores)].activo = True

    
#Método para generar recetas aleatoriamente
    def quiza_generar_orden(self, intervalo_generacion: float):
        ahora = time.time()
        if ahora - self.ultima_generacion_orden < intervalo_generacion:
            return
        if len(self.ordenes_activas) >= 4: 
            self.ultima_generacion_orden = ahora
            return
        recetas = self.tema["recetas"]
        receta = random.choice(recetas)
        self.ordenes_activas.append(Orden(receta))
        self.ultima_generacion_orden = ahora


#Este método busca formar una receta completa basandose en los ingredientes que se encuentran guardados en el depósito 
    def intentar_entregar_del_deposito(self) :
        if not self.entrega:
            return 0

        ganado = 0
        for orden in self.ordenes_activas[:]:
            if orden.completada or orden.fallida:
                continue
            indices_usados = []
            todo_ok = True
            for plantilla, cantidad in orden.receta.requisitos:
                contar = 0
                deposito = self.entrega.deposito
                for i, ingrediente in enumerate(deposito):
                    if i in indices_usados:
                        continue
                    if ingrediente.coincide(plantilla):
                        indices_usados.append(i)
                        contar += 1
                        if contar == cantidad:
                            break
                if contar < cantidad:
                    todo_ok = False
                    break
            if todo_ok:
                for i in sorted(indices_usados, reverse=True):
                    self.entrega.deposito.pop(i)
                orden.completada = True
                ganado += orden.obtener_puntuacion()
        if ganado:
            self.puntuacion += ganado
        self.ordenes_activas = [
            o for o in self.ordenes_activas
            if not o.completada and not o.fallida
        ]
        return ganado
#Método que registra la penalización a la puntuación por equivocarse 
    def penalizar_fallidas(self):
        penalizacion = 0
        restantes = []
        for orden in self.ordenes_activas:
            orden.actualizar()
            if orden.fallida:
                penalizacion += orden.receta.puntaje_base
            elif not orden.completada:
                restantes.append(orden)
        self.ordenes_activas = restantes
        if penalizacion:
            self.puntuacion = max(0, self.puntuacion - penalizacion)
        return penalizacion


#Loop que va actualizando los métodos generales de la cocina  
    def actualizar(self) :
        ahora = time.time()
        tiempo_delta = ahora - self.ultima_actualizacion
        self.ultima_actualizacion = ahora

        for est_trab in self.estaciones_trabajo:
            est_trab.actualizar()

        for orden in self.ordenes_activas:
            orden.actualizar()

        self.intentar_entregar_del_deposito()

        self.penalizar_fallidas()




