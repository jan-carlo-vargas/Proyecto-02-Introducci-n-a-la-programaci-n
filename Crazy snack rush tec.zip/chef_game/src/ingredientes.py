from enum import Enum


class TipoIngrediente(Enum):

    PROTEINA = "proteina"
    VEGETAL = "vegetal"
    PAPA = "papa"


class EstadoIngrediente(Enum):

    CRUDO = "crudo"
    COCINADO = "cocinado"  
    CORTADO = "cortado"      
    FRITO = "frito"          


TIPO_A_ESTADO_OBJETIVO = {
    TipoIngrediente.PROTEINA: EstadoIngrediente.COCINADO,
    TipoIngrediente.VEGETAL: EstadoIngrediente.CORTADO,
    TipoIngrediente.PAPA: EstadoIngrediente.FRITO,
}


class Ingrediente:

    _counter = 0

    def __init__(self, nombre: str, tipo: TipoIngrediente, color: str, estado_objetivo: EstadoIngrediente = None):
        Ingrediente._counter += 1
        self.id = Ingrediente._counter
        self.nombre = nombre
        self.tipo = tipo
        self.estado = EstadoIngrediente.CRUDO
        self.estado_objetivo = estado_objetivo or TIPO_A_ESTADO_OBJETIVO[tipo]
        self.color = color

    def procesar(self):
        self.estado = self.estado_objetivo

    def esta_procesado(self):
        return self.estado != EstadoIngrediente.CRUDO

    def coincide(self, otro: "Ingrediente"):
        return (self.nombre == otro.nombre and self.estado == otro.estado)

    def etiqueta(self):
        if self.esta_procesado():
            return f"{self.nombre[0]}{self.estado.value[0].upper()}"  
        return self.nombre[0]

    def __repr__(self):
        return f"Ingrediente({self.nombre}, {self.estado.value})"
