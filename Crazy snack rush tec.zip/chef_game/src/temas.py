
from .ingredientes import Ingrediente, TipoIngrediente, EstadoIngrediente
from .recetas import Receta


TEMA_1_NOMBRE = "Pizza hut china"

TEMA_1_LAYOUT = [
    "#############",
    "#...........#",
    "#.L.T.P.....#",
    "#...........#",
    "#...........#",
    "#...B.......#",
    "#...........#",
    "#....F...X..#",
    "#..1..2.....#",
]

TEMA_1_INGREDIENTES = {
    "L": Ingrediente("Lechuga", TipoIngrediente.VEGETAL, "#7CB342"),
    "T": Ingrediente("Tomate",  TipoIngrediente.VEGETAL, "#E53935"),
    "P": Ingrediente("Papa",    TipoIngrediente.PAPA,    "#D7CCC8"),
}

TEMA_1_RECETAS = [
    Receta("Ensalada", [
        (Ingrediente("Lechuga", TipoIngrediente.VEGETAL, "#7CB342",
                    estado_objetivo=EstadoIngrediente.CORTADO), 1),
        (Ingrediente("Tomate",  TipoIngrediente.VEGETAL, "#E53935",
                    estado_objetivo=EstadoIngrediente.CORTADO), 1),
    ], puntaje_base=60, tiempo_maximo=40),

    Receta("Papas Fritas", [
        (Ingrediente("Papa", TipoIngrediente.PAPA, "#D7CCC8",
                    estado_objetivo=EstadoIngrediente.FRITO), 2),
    ], puntaje_base=50, tiempo_maximo=35),

    Receta("Ensalada Grande", [
        (Ingrediente("Lechuga", TipoIngrediente.VEGETAL, "#7CB342",
                    estado_objetivo=EstadoIngrediente.CORTADO), 2),
        (Ingrediente("Tomate",  TipoIngrediente.VEGETAL, "#E53935",
                    estado_objetivo=EstadoIngrediente.CORTADO), 1),
    ], puntaje_base=90, tiempo_maximo=50),
]


TEMA_2_NOMBRE = "Hamburguesas Moiso"

TEMA_2_LAYOUT = [
    "#############",
    "#...........#",
    "#.M.L.T.P...#",
    "#...........#",
    "#...........#",
    "#....K......#",
    "#..B........#",
    "#.......F.X.#",
    "#..1...2....#",
]

TEMA_2_INGREDIENTES = {
    "M": Ingrediente("Carne",   TipoIngrediente.PROTEINA,  "#8D6E63"),
    "L": Ingrediente("Lechuga", TipoIngrediente.VEGETAL, "#7CB342"),
    "T": Ingrediente("Tomate",  TipoIngrediente.VEGETAL, "#E53935"),
    "P": Ingrediente("Papa",    TipoIngrediente.PAPA,    "#D7CCC8"),
}

TEMA_2_RECETAS = [
    Receta("Hamburguesa", [
        (Ingrediente("Carne", TipoIngrediente.PROTEINA, "#8D6E63",
                    estado_objetivo=EstadoIngrediente.COCINADO), 1),
        (Ingrediente("Lechuga", TipoIngrediente.VEGETAL, "#7CB342",
                    estado_objetivo=EstadoIngrediente.CORTADO), 1),
    ], puntaje_base=80, tiempo_maximo=45),

    Receta("Hamburguesa Doble", [
        (Ingrediente("Carne", TipoIngrediente.PROTEINA, "#8D6E63",
                    estado_objetivo=EstadoIngrediente.COCINADO), 2),
        (Ingrediente("Lechuga", TipoIngrediente.VEGETAL, "#7CB342",
                    estado_objetivo=EstadoIngrediente.CORTADO), 1),
        (Ingrediente("Tomate", TipoIngrediente.VEGETAL, "#E53935",
                    estado_objetivo=EstadoIngrediente.CORTADO), 1),
    ], puntaje_base=140, tiempo_maximo=60),

    Receta("Combo", [
        (Ingrediente("Carne", TipoIngrediente.PROTEINA, "#8D6E63",
                    estado_objetivo=EstadoIngrediente.COCINADO), 1),
        (Ingrediente("Papa", TipoIngrediente.PAPA, "#D7CCC8",
                    estado_objetivo=EstadoIngrediente.FRITO), 2),
    ], puntaje_base=120, tiempo_maximo=55),

    Receta("Papas Sola", [
        (Ingrediente("Papa", TipoIngrediente.PAPA, "#D7CCC8",
                    estado_objetivo=EstadoIngrediente.FRITO), 3),
    ], puntaje_base=70, tiempo_maximo=40),
]


TEMA_3_NOMBRE = "El novillo alegre :VVVV"

TEMA_3_LAYOUT = [
    "#############",
    "#...........#",
    "#.C.F.O.L.P.#",
    "#...........#",
    "#...........#",
    "#..K...K....#",
    "#...........#",
    "#..B.B.F.X..#",
    "#..1....2...#",
]

TEMA_3_INGREDIENTES = {
    "C": Ingrediente("Pollo",    TipoIngrediente.PROTEINA,   "#FFE082"),
    "F": Ingrediente("Pescado",  TipoIngrediente.PROTEINA,   "#90CAF9"),
    "O": Ingrediente("Cebolla",  TipoIngrediente.VEGETAL, "#CE93D8"),
    "L": Ingrediente("Lechuga",  TipoIngrediente.VEGETAL, "#7CB342"),
    "P": Ingrediente("Papa",     TipoIngrediente.PAPA,    "#D7CCC8"),
}

TEMA_3_RECETAS = [
    Receta("Pollo con Papas", [
        (Ingrediente("Pollo", TipoIngrediente.PROTEINA, "#FFE082",
                    estado_objetivo=EstadoIngrediente.COCINADO), 1),
        (Ingrediente("Papa", TipoIngrediente.PAPA, "#D7CCC8",
                    estado_objetivo=EstadoIngrediente.FRITO), 2),
    ], puntaje_base=120, tiempo_maximo=55),

    Receta("Ensalada César", [
        (Ingrediente("Lechuga", TipoIngrediente.VEGETAL, "#7CB342",
                    estado_objetivo=EstadoIngrediente.CORTADO), 2),
        (Ingrediente("Cebolla", TipoIngrediente.VEGETAL, "#CE93D8",
                    estado_objetivo=EstadoIngrediente.CORTADO), 1),
    ], puntaje_base=110, tiempo_maximo=50),

    Receta("Surf and Turf", [
        (Ingrediente("Pollo",   TipoIngrediente.PROTEINA, "#FFE082",
                    estado_objetivo=EstadoIngrediente.COCINADO), 1),
        (Ingrediente("Pescado", TipoIngrediente.PROTEINA, "#90CAF9",
                    estado_objetivo=EstadoIngrediente.COCINADO), 1),
    ], puntaje_base=180, tiempo_maximo=70),

    Receta("Pescado y Papas", [
        (Ingrediente("Pescado", TipoIngrediente.PROTEINA, "#90CAF9",
                    estado_objetivo=EstadoIngrediente.COCINADO), 1),
        (Ingrediente("Papa", TipoIngrediente.PAPA, "#D7CCC8",
                    estado_objetivo=EstadoIngrediente.FRITO), 2),
    ], puntaje_base=150, tiempo_maximo=60),
]



TODOS_LOS_TEMAS = [
    {
        "nombre": TEMA_1_NOMBRE,
        "mapa": TEMA_1_LAYOUT,
        "ingredientes": TEMA_1_INGREDIENTES,
        "recetas": TEMA_1_RECETAS,
        "dificultad": "Fácil",
    },
    {
        "nombre": TEMA_2_NOMBRE,
        "mapa": TEMA_2_LAYOUT,
        "ingredientes": TEMA_2_INGREDIENTES,
        "recetas": TEMA_2_RECETAS,
        "dificultad": "Medio",
    },
    {
        "nombre": TEMA_3_NOMBRE,
        "mapa": TEMA_3_LAYOUT,
        "ingredientes": TEMA_3_INGREDIENTES,
        "recetas": TEMA_3_RECETAS,
        "dificultad": "Difícil",
    },
]
