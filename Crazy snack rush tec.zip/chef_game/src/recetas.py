
import time

from .ingredientes import Ingrediente


class Receta:

    def __init__(self, nombre: str, requisitos, puntaje_base: int, tiempo_maximo: float):
        self.nombre = nombre
        self.requisitos = []
        for ing, qty in requisitos:
            template = Ingrediente(
                ing.nombre, ing.tipo, ing.color,
                estado_objetivo=ing.estado_objetivo,
            )
            template.estado = ing.estado_objetivo
            self.requisitos.append((template, qty))
        self.puntaje_base = puntaje_base
        self.tiempo_maximo = tiempo_maximo

    def descripcion(self):
        parts = []
        for ing, qty in self.requisitos:
            state_label = ing.estado.value
            parts.append(f"{qty}× {ing.nombre}({state_label})")
        return " + ".join(parts)


class Orden:

    def __init__(self, receta: Receta):
        self.receta = receta
        self.creada_en = time.time()
        self.limite = self.creada_en + receta.tiempo_maximo
        self.ciclos_vencidos = 0
        self.puntaje_actual = receta.puntaje_base
        self.entregados: list = []  
        self.completada = False
        self.fallida = False

    def intentar_coincidencia(self, ingrediente) -> bool:
        if self.completada or self.fallida:
            return False
        for template, required_qty in self.receta.requisitos:
            already = sum(1 for ing in self.entregados if ing.coincide(template))
            if ingrediente.coincide(template) and already < required_qty:
                self.entregados.append(ingrediente)
                return True
        return False

    def faltantes(self):
        missing = []
        for template, qty in self.receta.requisitos:
            already = sum(1 for ing in self.entregados if ing.coincide(template))
            if already < qty:
                missing.append((template, qty - already))
        return missing

    def esta_completa(self):
        return len(self.faltantes()) == 0


    def actualizar(self):
        if self.completada or self.fallida:
            return
        elapsed = time.time() - self.creada_en
        cycles = int(elapsed // self.receta.tiempo_maximo)
        if cycles > self.ciclos_vencidos:
            self.ciclos_vencidos = cycles
            self.puntaje_actual = self.receta.puntaje_base / (2 ** cycles)
            if self.puntaje_actual < 1:
                self.puntaje_actual = 0
                self.fallida = True

    def obtener_puntuacion(self):
        self.actualizar()
        return int(self.puntaje_actual)

    def tiempo_restante(self):
        if self.completada or self.fallida:
            return 0.0
        return max(0.0, self.limite - time.time())

    def urgencia(self):
        ratio = self.tiempo_restante() / self.receta.tiempo_maximo
        if ratio > 0.5:
            return "ok"
        if ratio > 0.25:
            return "warning"
        return "urgent"


