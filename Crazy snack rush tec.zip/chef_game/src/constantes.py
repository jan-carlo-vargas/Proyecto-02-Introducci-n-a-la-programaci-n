

#Dimensiones del canvas
TAMAÑO_CELDA = 64
COLS_GRID = 13
FILAS_GRID = 9
ANCHO_CANVAS = TAMAÑO_CELDA * COLS_GRID
ALTO_CANVAS = TAMAÑO_CELDA * FILAS_GRID
ALTO_HUD = 140
ANCHO_VENTANA = ANCHO_CANVAS
ALTO_VENTANA = ALTO_CANVAS + ALTO_HUD

#Controles
MOVER_ARRIBA = "w"
MOVER_ABAJO = "s"
MOVER_IZQUIERDA = "a"
MOVER_DERECHA = "d"
TECLA_ACCION = "space"
TECLA_CAMBIO = "Tab"

#Tiempos del juego
RETARDO_MOVIMIENTO = 0.13
ENFRIAMIENTO_ACCION = 0.25
INTERVALO_SPAWN_ORDEN = 9.0
DURACION_JUEGO = 120  

#Colores para los canvas de tkinter, pueden ser remplazados por sprites
COLORES = {
    "floor": "#F5F5DC",
    "floor_alt": "#ECE5C7",
    "wall": "#3E2723",
    "grid_line": "#D7C99E",
    "hud_bg": "#212121",
    "hud_text": "#FFFFFF",
    "hud_accent": "#FFC107",
    "chef1": "#E53935",
    "chef2": "#1E88E5",
    "chef_inactive": "#9E9E9E",
    "ingredient_raw_border": "#000000",
    "order_bg": "#FFFFFF",
    "order_urgent": "#E53935",
    "order_warning": "#FB8C00",
    "order_ok": "#43A047",
    "delivery": "#FF7043",
    "pantry": "#8D6E63",
    "kitchen": "#FFB300",
    "cutting": "#43A047",
    "fryer": "#D32F2F",
    "counter": "#90A4AE",
}
