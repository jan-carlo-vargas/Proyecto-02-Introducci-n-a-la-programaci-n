#Bloque de importanciones
import time
from enum import Enum

from .ingredientes import Ingrediente, EstadoIngrediente, TipoIngrediente


class TipoEstacion(Enum):
    DESPENSA = "despensa"
    ENTREGA = "entrega"
    COCINA = "cocina"
    CORTE = "corte"
    FREIDORA = "freidora"


class Estacion:
    def __init__(self, x: int, y: int, tipo_estacion: TipoEstacion):
        self.x = x
        self.y = y
        self.tipo = tipo_estacion

    def obtener_color(self):
        return "#FFFFFF"

    def obtener_etiqueta(self):
        return ""


class EstacionDespensa(Estacion):

    def __init__(self, x: int, y: int, template_ingrediente: Ingrediente):
        super().__init__(x, y, TipoEstacion.DESPENSA)
        self.template = template_ingrediente

    def dispensar(self):
        new_ing = Ingrediente(
            self.template.nombre,
            self.template.tipo,
            self.template.color,
            self.template.estado_objetivo,
        )
        new_ing.color = self.template.color
        return new_ing

    def obtener_color(self) -> str:
        return self.template.color

    def obtener_etiqueta(self) -> str:
        return self.template.nombre[0]


class EstacionEntrega(Estacion):

    def __init__(self, x: int, y: int):
        super().__init__(x, y, TipoEstacion.ENTREGA)
        self.deposito: list[Ingrediente] = []

    def depositar(self, ingrediente: Ingrediente):
        self.deposito.append(ingrediente)

    def quitar_primero(self, ingrediente: Ingrediente):
        for i, ing in enumerate(self.deposito):
            if ing.coincide(ingrediente):
                self.deposito.pop(i)
                return True
        return False

    def obtener_color(self):
        return "#FF7043"

    def obtener_etiqueta(self):
        return "X"


class EstacionTrabajo(Estacion):

    TIEMPO_PROCESAMIENTO = 1.5

    def __init__(self, x: int, y: int, tipo_estacion: TipoEstacion, tiempo_procesamiento: float = None):
        super().__init__(x, y, tipo_estacion)
        self.tiempo_procesamiento = tiempo_procesamiento if tiempo_procesamiento else self.TIEMPO_PROCESAMIENTO
        self.actual: Ingrediente | None = None
        self.cola: list[Ingrediente] = []
        self.listo: Ingrediente | None = None
        self.progreso = 0.0
        self.ultima_actualizacion = time.time()


    def puede_aceptar(self, ingrediente: Ingrediente):
        raise NotImplementedError

    def poner(self, ingrediente: Ingrediente):
        if not self.puede_aceptar(ingrediente):
            return False
        if self.actual is None:
            self.actual = ingrediente
            self.progreso = 0.0
            self.ultima_actualizacion = time.time()
        else:
            self.cola.append(ingrediente)
        return True

    def tomar_listo(self):
        listo = self.listo
        self.listo = None
        return listo

    def tiene_listo(self):
        return self.listo is not None

    def actualizar(self):
        if self.actual is None:
            self.ultima_actualizacion = time.time()
            return

        now = time.time()
        dt = now - self.ultima_actualizacion
        self.ultima_actualizacion = now
        self.progreso += dt / self.tiempo_procesamiento

        if self.progreso >= 1.0:
            self.actual.procesar()
            self.listo = self.actual
            self.actual = None
            self.progreso = 0.0
            if self.cola:
                self.actual = self.cola.pop(0)
                self.ultima_actualizacion = time.time()


class EstacionCocina(EstacionTrabajo):

    TIEMPO_PROCESAMIENTO = 3.0

    def __init__(self, x: int, y: int):
        super().__init__(x, y, TipoEstacion.COCINA)
        self.color = "#FFB300"

    def puede_aceptar(self, ingrediente: Ingrediente):
        return (ingrediente.tipo == TipoIngrediente.PROTEINA
                and not ingrediente.esta_procesado())

    def obtener_color(self):
        return self.color

    def obtener_etiqueta(self):
        return "K"


class EstacionCorte(EstacionTrabajo):
    TIEMPO_PROCESAMIENTO = 1.0

    def __init__(self, x: int, y: int):
        super().__init__(x, y, TipoEstacion.CORTE)
        self.color = "#43A047"

    def puede_aceptar(self, ingrediente: Ingrediente):
        return (ingrediente.tipo == TipoIngrediente.VEGETAL
                and not ingrediente.esta_procesado())

    def obtener_color(self):
        return self.color

    def obtener_etiqueta(self):
        return "C"


class EstacionFreidora(EstacionTrabajo):
    TIEMPO_PROCESAMIENTO = 2.0

    def __init__(self, x: int, y: int):
        super().__init__(x, y, TipoEstacion.FREIDORA)
        self.color = "#D32F2F"

    def puede_aceptar(self, ingrediente: Ingrediente):
        return (ingrediente.tipo == TipoIngrediente.PAPA
                and not ingrediente.esta_procesado())

    def obtener_color(self):
        return self.color

    def obtener_etiqueta(self):
        return "F"


def crear_estacion(char: str, x: int, y: int, ingredientes_despensa: dict):
    char = char.upper()
    if char == "K":
        return EstacionCocina(x, y)
    if char == "B":
        return EstacionCorte(x, y)
    if char == "F":
        return EstacionFreidora(x, y)
    if char == "X":
        return EstacionEntrega(x, y)
    if char in ingredientes_despensa:
        return EstacionDespensa(x, y, ingredientes_despensa[char])
    return None



