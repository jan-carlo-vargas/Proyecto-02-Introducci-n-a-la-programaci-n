#Clase principal que interconecta todos los recursos en una ventana de tkinter y ejecuta el juego como tal 


#Bloque de importaciones de bibliotecas externas, time para las funciones de temporizador y tkinter para la interfaz gráfica
import time
import tkinter as tk
from tkinter import messagebox

#Bloque de importación de módulos internos
from .jugadores import Cocinero
from .constantes import (
    TAMAÑO_CELDA, COLS_GRID, FILAS_GRID, ANCHO_CANVAS, ALTO_CANVAS,
    ALTO_HUD, ANCHO_VENTANA, ALTO_VENTANA,
    MOVER_ARRIBA, MOVER_ABAJO, MOVER_IZQUIERDA, MOVER_DERECHA,
    TECLA_ACCION, TECLA_CAMBIO,
    RETARDO_MOVIMIENTO, ENFRIAMIENTO_ACCION, INTERVALO_SPAWN_ORDEN, DURACION_JUEGO,
    COLORES,
)
from .cocina import Cocina
from .estaciones import TipoEstacion, EstacionDespensa, EstacionEntrega, EstacionTrabajo
from .temas import TODOS_LOS_TEMAS


class Juego:

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Chef Rush — Cocina Colaborativa")
        self.root.configure(bg="#212121")
        self.root.resizable(False, False)

        # Estado
        self.cocina_actual: Cocina | None = None
        self.indice_tema_actual = 0
        self.mode = "menu"  
        self.game_start_time = 0.0
        self.final_score = 0
        self.completed_kitchens = []  

        self.canvas = tk.Canvas(
            self.root,
            width=ANCHO_VENTANA,
            height=ALTO_VENTANA,
            bg=COLORES["hud_bg"],
            highlightthickness=0,
        )
        self.canvas.pack()

        self.root.bind("<KeyPress>", self._on_key_press)
        self.root.bind("<Tab>", lambda e: self._on_key_press(e))
        self.root.bind("<space>", lambda e: self._on_key_press(e))
        self.canvas.focus_set()

        self._draw_menu()
        self._schedule_tick()


    def _schedule_tick(self):
        self.root.after(50, self._tick)
        self.canvas.focus_set()

    def _tick(self):
        if self.mode == "playing" and self.cocina_actual:
            self.cocina_actual.quiza_generar_orden(INTERVALO_SPAWN_ORDEN)
            self.cocina_actual.actualizar()
            elapsed = time.time() - self.game_start_time
            if elapsed >= DURACION_JUEGO:
                self._end_current_kitchen()
        self._render()
        self._schedule_tick()


    def _on_key_press(self, event):
        key = event.keysym.lower()

        if self.mode == "menu":
            if key in ("1", "2", "3"):
                idx = int(key) - 1
                if idx < len(TODOS_LOS_TEMAS):
                    self._start_kitchen(idx)
            elif key == "return":
                self._start_kitchen(self.indice_tema_actual)
            elif key in ("left", "a") and self.indice_tema_actual > 0:
                self.indice_tema_actual -= 1
                self._draw_menu()
            elif key in ("right", "d") and self.indice_tema_actual < len(TODOS_LOS_TEMAS) - 1:
                self.indice_tema_actual += 1
                self._draw_menu()
            elif key == "escape":
                self.root.quit()
            return

        if self.mode == "gameover":
            if key == "return":
                if self.indice_tema_actual < len(TODOS_LOS_TEMAS) - 1:
                    # pasar a la siguiente cocina
                    self.indice_tema_actual += 1
                    self._start_kitchen(self.indice_tema_actual)
                else:
                    self._show_final_results()
            elif key == "m":
                self.mode = "menu"
                self.indice_tema_actual = 0
                self.completed_kitchens = []
                self._draw_menu()
            elif key == "r":
                self._start_kitchen(self.indice_tema_actual)
            elif key == "escape":
                self.root.quit()
            return

        if self.mode != "playing" or not self.cocina_actual:
            return

        cocinero = self.cocina_actual.obtener_jugador_activo()
        if not cocinero:
            return

        now = time.time()

        if key == MOVER_ABAJO:
            cocinero.intentar_mover(0, 1, self.cocina_actual, now, RETARDO_MOVIMIENTO)
        elif key == MOVER_ARRIBA:
            cocinero.intentar_mover(0, -1, self.cocina_actual, now, RETARDO_MOVIMIENTO)
        elif key == MOVER_IZQUIERDA:
            cocinero.intentar_mover(-1, 0, self.cocina_actual, now, RETARDO_MOVIMIENTO)
        elif key == MOVER_DERECHA:
            cocinero.intentar_mover(1, 0, self.cocina_actual, now, RETARDO_MOVIMIENTO)
        elif key == "tab":
            self.cocina_actual.cambiar_jugador()
        elif key in ("space", "return"):
            self._handle_action(cocinero, now)
        elif key == "escape":
            # salir al menú
            self.mode = "menu"
            self._draw_menu()

    def _handle_action(self, cocinero: Cocinero, now: float):
        if not cocinero.puede_actuar(now, ENFRIAMIENTO_ACCION):
            return
        cocinero.marcar_accion(now)

        candidates = []
        for dx, dy in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            nx, ny = cocinero.x + dx, cocinero.y + dy
            estacion = self.cocina_actual.obtener_estacion_en(nx, ny)
            if estacion:
                candidates.append(estacion)

        if not candidates:
            return

        if cocinero.tiene_ingrediente():
            for s in candidates:
                if isinstance(s, EstacionTrabajo) and s.puede_aceptar(cocinero.sostiene):
                    if s.poner(cocinero.soltar()):
                        return
            for s in candidates:
                if isinstance(s, EstacionEntrega):
                    ing = cocinero.soltar()
                    s.depositar(ing)
                    return
        else:
            for s in candidates:
                if isinstance(s, EstacionDespensa):
                    cocinero.recoger(s.dispensar())
                    return
            for s in candidates:
                if isinstance(s, EstacionTrabajo) and s.tiene_listo():
                    cocinero.recoger(s.tomar_listo())
                    return


    def _start_kitchen(self, theme_index: int):
        tema = TODOS_LOS_TEMAS[theme_index]
        self.cocina_actual = Cocina(tema)
        self.cocina_actual.tema = tema  
        self.indice_tema_actual = theme_index
        self.game_start_time = time.time()
        self.mode = "playing"

    def _end_current_kitchen(self):
        if not self.cocina_actual:
            return
        self.final_score = self.cocina_actual.puntuacion
        self.completed_kitchens.append(
            (self.cocina_actual.nombre_tema, self.final_score)
        )
        self.mode = "gameover"

    def _show_final_results(self):
        lines = ["Resultados finales:"]
        for name, score in self.completed_kitchens:
            lines.append(f"  • {name}: {score} pts")
        messagebox.showinfo("Resultados", "\n".join(lines))
        self.mode = "menu"
        self.indice_tema_actual = 0
        self.completed_kitchens = []
        self._draw_menu()


    def _draw_menu(self):
        self.canvas.delete("all")
        self.canvas.create_rectangle(
            0, 0, ANCHO_VENTANA, ALTO_VENTANA,
            fill="#1B5E20", outline=""
        )
        self.canvas.create_text(
            ANCHO_VENTANA // 2, 80,
            text="CHEF RUSH",
            fill="#FFC107", font=("Helvetica", 36, "bold")
        )
        self.canvas.create_text(
            ANCHO_VENTANA // 2, 130,
            text="Cocina Colaborativa",
            fill="#FFFFFF", font=("Helvetica", 16)
        )

        for i, theme in enumerate(TODOS_LOS_TEMAS):
            x = 80 + i * 250
            y = 220
            is_selected = (i == self.indice_tema_actual)
            box_color = "#FFC107" if is_selected else "#FFFFFF"
            text_color = "#000000" if is_selected else "#FFFFFF"
            self.canvas.create_rectangle(
                x, y, x + 220, y + 200,
                fill=box_color if is_selected else "#2E7D32",
                outline="#FFC107" if is_selected else "#FFFFFF",
                width=3,
            )
            self.canvas.create_text(
                x + 110, y + 40,
                text=f"{i + 1}. {theme['nombre']}",
                fill=text_color, font=("Helvetica", 16, "bold"),
            )
            self.canvas.create_text(
                x + 110, y + 75,
                text=f"Dificultad: {theme['dificultad']}",
                fill=text_color, font=("Helvetica", 12),
            )
            self.canvas.create_text(
                x + 110, y + 100,
                text=f"Recetas: {len(theme['recetas'])}",
                fill=text_color, font=("Helvetica", 12),
            )
            self.canvas.create_text(
                x + 110, y + 125,
                text=f"Ingredientes: {len(theme['ingredientes'])}",
                fill=text_color, font=("Helvetica", 12),
            )
            self.canvas.create_text(
                x + 110, y + 165,
                text="ENTER para jugar",
                fill="#FFC107" if not is_selected else "#000000",
                font=("Helvetica", 11, "bold"),
            )

        self.canvas.create_text(
            ANCHO_VENTANA // 2, ALTO_VENTANA - 80,
            text="Usa ←/→ para seleccionar — ENTER para jugar — ESC para salir",
            fill="#FFFFFF", font=("Helvetica", 12),
        )


    def _render(self) -> None:
        if self.mode == "menu":
            return 
        if self.mode == "gameover":
            self._draw_gameover()
            return
        self._draw_game()

    def _draw_game(self) -> None:
        self.canvas.delete("all")
        k = self.cocina_actual
        if not k:
            return

        for y in range(FILAS_GRID):
            for x in range(COLS_GRID):
                if (x, y) in k.muros:
                    self.canvas.create_rectangle(
                        x * TAMAÑO_CELDA, y * TAMAÑO_CELDA,
                        (x + 1) * TAMAÑO_CELDA, (y + 1) * TAMAÑO_CELDA,
                        fill=COLORES["wall"], outline="",
                    )
                else:
                    color = COLORES["floor"] if (x + y) % 2 == 0 else COLORES["floor_alt"]
                    self.canvas.create_rectangle(
                        x * TAMAÑO_CELDA, y * TAMAÑO_CELDA,
                        (x + 1) * TAMAÑO_CELDA, (y + 1) * TAMAÑO_CELDA,
                        fill=color, outline=COLORES["grid_line"],
                    )

        for (x, y), estacion in k.estaciones.items():
            self._draw_estacion(x, y, estacion)

        for cocinero in k.jugadores:
            self._draw_cocinero(cocinero)

        self._draw_hud()

    def _draw_estacion(self, x: int, y: int, estacion):
        px = x * TAMAÑO_CELDA
        py = y * TAMAÑO_CELDA
        self.canvas.create_rectangle(
            px + 4, py + 4, px + TAMAÑO_CELDA - 4, py + TAMAÑO_CELDA - 4,
            fill=estacion.obtener_color(), outline="#000000", width=2,
        )
        self.canvas.create_text(
            px + TAMAÑO_CELDA // 2, py + TAMAÑO_CELDA // 2 - 8,
            text=estacion.obtener_etiqueta(),
            fill="#FFFFFF", font=("Helvetica", 20, "bold"),
        )

        if isinstance(estacion, EstacionTrabajo):
            if estacion.actual:
                self.canvas.create_rectangle(
                    px + 8, py + TAMAÑO_CELDA - 18,
                    px + TAMAÑO_CELDA - 8, py + TAMAÑO_CELDA - 8,
                    fill="#FFFFFF", outline="",
                )
                self.canvas.create_rectangle(
                    px + 8, py + TAMAÑO_CELDA - 18,
                    px + 8 + (TAMAÑO_CELDA - 16) * estacion.progreso,
                    py + TAMAÑO_CELDA - 8,
                    fill=estacion.actual.color, outline="",
                )
            elif estacion.listo:
                self.canvas.create_oval(
                    px + 12, py + 12, px + TAMAÑO_CELDA - 12, py + TAMAÑO_CELDA - 12,
                    fill=estacion.listo.color, outline="#FFFF00", width=3,
                )

        if isinstance(estacion, EstacionEntrega):
            if estacion.deposito:
                n = len(estacion.deposito)
                self.canvas.create_text(
                    px + TAMAÑO_CELDA // 2, py + TAMAÑO_CELDA - 14,
                    text=f"x{n}",
                    fill="#FFFFFF", font=("Helvetica", 12, "bold"),
                )

    def _draw_cocinero(self, cocinero: Cocinero):
        px = cocinero.x * TAMAÑO_CELDA
        py = cocinero.y * TAMAÑO_CELDA
        margin = 8
        color = cocinero.color if cocinero.activo else COLORES["chef_inactive"]

        self.canvas.create_oval(
            px + margin, py + margin,
            px + TAMAÑO_CELDA - margin, py + TAMAÑO_CELDA - margin,
            fill=color, outline="#FFFFFF" if cocinero.activo else "#000000",
            width=3 if cocinero.activo else 2,
        )


        if cocinero.activo:
            self.canvas.create_polygon(
                px + TAMAÑO_CELDA // 2, py + 2,
                px + TAMAÑO_CELDA // 2 - 6, py + 12,
                px + TAMAÑO_CELDA // 2 + 6, py + 12,
                fill="#FFC107", outline="",
            )
        if cocinero.sostiene:
            ing_x = px + TAMAÑO_CELDA // 2
            ing_y = py - 8
            self.canvas.create_rectangle(
                ing_x - 10, ing_y - 10, ing_x + 10, ing_y + 10,
                fill=cocinero.sostiene.color,
                outline="#000000", width=2,
            )


    def _draw_hud(self):
        k = self.cocina_actual
        if not k:
            return

        hud_y = ALTO_CANVAS

        self.canvas.create_rectangle(
            0, hud_y, ANCHO_VENTANA, ALTO_VENTANA,
            fill=COLORES["hud_bg"], outline="",
        )

        elapsed = time.time() - self.game_start_time
        remaining = max(0, DURACION_JUEGO - elapsed)
        mins = int(remaining) // 60
        secs = int(remaining) % 60

        self.canvas.create_text(
            20, hud_y + 22,
            text=f"⏱  {mins}:{secs:02d}",
            fill="#FFFFFF", font=("Helvetica", 18, "bold"),
            anchor="w",
        )
        self.canvas.create_text(
            ANCHO_VENTANA - 20, hud_y + 22,
            text=f"🏆  {k.puntuacion}",
            fill=COLORES["hud_accent"], font=("Helvetica", 18, "bold"),
            anchor="e",
        )

        self.canvas.create_text(
            20, hud_y + 48,
            text=f"🍳  {k.nombre_tema}",
            fill="#FFFFFF", font=("Helvetica", 12),
            anchor="w",
        )
        self.canvas.create_text(
            ANCHO_VENTANA - 20, hud_y + 48,
            text="WASD mover | ESPACIO actuar | TAB cambiar cocinero",
            fill="#BBBBBB", font=("Helvetica", 11),
            anchor="e",
        )

        # --- Órdenes activas ---
        orders_label_y = hud_y + 75
        self.canvas.create_text(
            20, orders_label_y,
            text="Órdenes:",
            fill="#FFFFFF", font=("Helvetica", 12, "bold"),
            anchor="w",
        )

        ox = 110
        for orden in k.ordenes_activas[:5]:  
            orden.actualizar()
            self._draw_orden(orden, ox, orders_label_y + 8)
            ox += 150

    def _draw_orden(self, orden, x: int, y: int) -> None:
        width = 140
        height = 56
        urgency_color = {
            "ok": COLORES["order_ok"],
            "warning": COLORES["order_warning"],
            "urgent": COLORES["order_urgent"],
        }.get(orden.urgencia(), COLORES["order_ok"])

        self.canvas.create_rectangle(
            x, y, x + width, y + height,
            fill=urgency_color, outline="#FFFFFF", width=2,
        )
        self.canvas.create_text(
            x + 8, y + 14,
            text=orden.receta.nombre,
            fill="#FFFFFF", font=("Helvetica", 11, "bold"),
            anchor="w",
        )
        self.canvas.create_text(
            x + width - 8, y + 14,
            text=f"+{orden.obtener_puntuacion()}",
            fill="#FFFFFF", font=("Helvetica", 11, "bold"),
            anchor="e",
        )
        self.canvas.create_text(
            x + 8, y + 30,
            text=f"⏱ {int(orden.tiempo_restante())}s",
            fill="#FFFFFF", font=("Helvetica", 10),
            anchor="w",
        )
        missing = orden.faltantes()
        parts = [f"{qty}×{ing.nombre[0]}({ing.estado.value[0].upper()})"
                 for ing, qty in missing]
        self.canvas.create_text(
            x + 8, y + 46,
            text="Falta: " + " ".join(parts) if parts else "¡LISTA!",
            fill="#FFFFFF", font=("Helvetica", 9),
            anchor="w",
        )


    def _draw_gameover(self):
        k = self.cocina_actual
        self.canvas.delete("all")
        self.canvas.create_rectangle(
            0, 0, ANCHO_VENTANA, ALTO_VENTANA,
            fill="#212121", outline="",
        )
        self.canvas.create_text(
            ANCHO_VENTANA // 2, 80,
            text="¡TIEMPO TERMINADO!",
            fill="#FFC107", font=("Helvetica", 28, "bold"),
        )
        self.canvas.create_text(
            ANCHO_VENTANA // 2, 140,
            text=f"Cocina: {k.nombre_tema}",
            fill="#FFFFFF", font=("Helvetica", 16),
        )
        self.canvas.create_text(
            ANCHO_VENTANA // 2, 180,
            text=f"Puntaje final: {self.final_score}",
            fill="#FFC107", font=("Helvetica", 22, "bold"),
        )

        is_last = self.indice_tema_actual >= len(TODOS_LOS_TEMAS) - 1
        if not is_last:
            self.canvas.create_text(
                ANCHO_VENTANA // 2, 260,
                text="ENTER → Siguiente cocina",
                fill="#FFFFFF", font=("Helvetica", 14),
            )
        else:
            self.canvas.create_text(
                ANCHO_VENTANA // 2, 260,
                text="ENTER → Ver resultados finales",
                fill="#FFFFFF", font=("Helvetica", 14),
            )
        self.canvas.create_text(
            ANCHO_VENTANA // 2, 300,
            text="R → Repetir esta cocina",
            fill="#FFFFFF", font=("Helvetica", 14),
        )
        self.canvas.create_text(
            ANCHO_VENTANA // 2, 340,
            text="M → Volver al menú",
            fill="#FFFFFF", font=("Helvetica", 14),
        )

    
    def ejecutar(self):
        self.root.mainloop()

